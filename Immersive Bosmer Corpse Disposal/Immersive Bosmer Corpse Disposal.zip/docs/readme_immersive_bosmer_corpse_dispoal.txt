===============================================================================
|                        Immersive Bosmer Corpse Disposal                     |
|                                 Version 1.0                                 |
|                                  by rfuzzo                                  |
===============================================================================

-------------
Description |
-------------

This mod changes the "dispose corpse" button to "eat corpse" if you are playing as a Bosmer and adds some buffs for eating your felled enemies.

MCM configurables:

- Only enable corpse eating if you are playing as a Bosmer. (On by default)
- Only enable corpse eating if your class contains the words 'green pact'. (Off by default)

--------------
Installation |
--------------

This mod requires MGE XE and the latest version of MWSE. Just install MGE
XE and run MWSE-Update.exe to download the latest build.

Use a mod management tool such as Wrye Mash or MO2, or just copy the MWSE directory to
your Data Files directory.

---------
Credits |
---------

Thanks to the MMC discord for being an amazing community.
Thanks to the MWSE team for MWSE.
Thanks to NullCascade, Sephumbra for help with the coding.

-----------
Changelog |
-----------

Version 1.0
   - Initial release.