===============================================================================
|                          MWSE Loading Splash Screens                        |
|                                 Version 1.0                                 |
|                                  by rfuzzo                                  |
===============================================================================

-------------
Description |
-------------

This mod uses MWSE to display splash screens during cell loading instead of freezing the frame as vanilla does.

MCM configurables:

- The alpha value (transparency) of the loading splash screen.

--------------
Installation |
--------------

Use a mod management tool such as Wrye Mash or MO2, or just copy the MWSE directory to
your Data Files directory.

--------------
Requirements |
--------------

This mod requires MGE XE and the latest version of MWSE. Just install MGE
XE and run MWSE-Update.exe to download the latest build.

---------
Credits |
---------

Thanks to the MWSE team for MWSE.
Thanks to NullCascade, Sephumbra for help with the coding.

-----------
Changelog |
-----------

Version 1.0
   - Initial release.