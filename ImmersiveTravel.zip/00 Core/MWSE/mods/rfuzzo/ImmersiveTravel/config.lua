local defaultConfig = {
    mod = "Immersive Travel",
    id = "IT",
    version = 1.0,
    author = "rfuzzo",
    -- configs
    freemovement = true,
    logLevel = "INFO"
}

return mwse.loadConfig("ImmersiveTravel", defaultConfig)
