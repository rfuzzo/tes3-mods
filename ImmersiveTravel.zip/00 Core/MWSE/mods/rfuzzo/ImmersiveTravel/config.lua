local defaultConfig = {
    mod = "Immersive Travel",
    id = "IT",
    version = 1.0,
    author = "rfuzzo",
    -- configs
    logLevel = "INFO"
}

return mwse.loadConfig("ImmersiveTravel", defaultConfig)
