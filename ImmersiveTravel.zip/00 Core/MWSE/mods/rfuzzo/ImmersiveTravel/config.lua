local defaultConfig = {
    mod = "Immersive Travel",
    id = "IT",
    version = 1.0,
    author = "rfuzzo",
    -- configs
    logLevel = "INFO",
    a_siltstrider_forwardAnimation = "runForward"
}

return mwse.loadConfig("ImmersiveTravel", defaultConfig)
